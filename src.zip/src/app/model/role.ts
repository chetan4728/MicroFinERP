export class Role {

    role_id: number;
    role_code: string;
    role_name: string;
    status: number;
}
