export class FinanicalYear {

    year_id: number;
    year_name: string;
    status: number;
}