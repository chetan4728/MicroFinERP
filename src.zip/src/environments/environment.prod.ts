export const environment = {
  api: 'https://nisargenterprises.in/BankERP/api/',
  userSession: 'userSession',
  production: true
};
