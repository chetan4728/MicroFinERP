import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cgt1',
  templateUrl: './cgt1.component.html',
  styleUrls: ['./cgt1.component.scss']
})
export class Cgt1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
