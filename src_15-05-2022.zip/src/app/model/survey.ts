export class Survey {
    bank_id:any;
    assign_area_id: number;
    area_name: String;
    branch_id: number;
    user_id: number;
    date_assigned:any;
    latitude: any;
    longitude: any;
   
}
