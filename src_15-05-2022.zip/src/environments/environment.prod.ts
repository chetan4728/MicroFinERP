export const environment = {
  api: 'http://sfsfin.in/portal/api/',
  uploads: 'http://sfsfin.in/portal/uploads/Documents/',
  userSession: 'userSession',
  SessionTime: 3600,
  production: true
};
