import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superfooter',
  templateUrl: './superfooter.component.html',
  styleUrls: ['./superfooter.component.scss']
})
export class SuperfooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
