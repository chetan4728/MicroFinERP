export class Centers {

}
