export class Area {

    area_id: number;
    area_name: string;
    bank_id: number;
    status: any;
    branch_name: string; 
    latitude:number;
    longitude:number;
}