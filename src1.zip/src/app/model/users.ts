export class Users {

    employee_id: number;
    employee_first_name: string;
    employee_middle_name: string;
    employee_last_name: string;
    employee_gender: any;
    employee_state_id: any;
    employee_district_id: any;
    employee_address: string;
    employee_dob: string;
    employee_role_id: any;
    employee_contact_no: string;
    employee_alt_contact_no: string;
    employee_pan_card_no: string;
    employee_adhar_card_no: string;
    employee_email_id: string;
    profile: string;
    employee_bank_id: number;
    employee_branch_id: any;
    employee_center_id: number;
    employee_login_code: number;
    employee_login_password: number;
    employee_status: any;
    bank_id:number;
}
