export class Survey {

    assign_area_id: number;
    area_name: String;
    branch_id: number;
    user_id: number;
    latitude: any;
    longitude: any;
   
}
